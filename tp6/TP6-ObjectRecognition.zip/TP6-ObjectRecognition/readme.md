Retrieve the data files from this URL: https://cloud.univ-grenoble-alpes.fr/s/r6Z7Mc2GJcn8cSa. 

It's recommended to free up some space on your machine as the downloaded file is approximately 1.3G and the data files require about 5.5G.

Store the training and validation data in a directory called /data