import torch
import matplotlib.pyplot as plt

class Trainer:
    def __init__(self, model, train_loader, val_loader, test_loader, criterion, optimizer, device):
        """
        A utility class for training, validating and testing a PyTorch model.

        Attributes:
            model (nn.Module): The PyTorch model to train.
            train_loader (DataLoader): The DataLoader for the training data.
            val_loader (DataLoader): The DataLoader for the validation data.
            test_loader (DataLoader): The DataLoader for the test data.
            criterion (nn.Module): The loss function.
            optimizer (Optimizer): The optimizer.
            device (torch.device): The device to train on (e.g., 'cpu' or 'cuda').
            best_accuracy (float): The best validation accuracy seen so far during training.

        Methods:
            train(epochs, patience): Trains the model for a given number of epochs, with early stopping.
            evaluate(): Evaluates the model on the test data.
            predict(inputs): Makes predictions on a batch of inputs.
            plot_metrics(train_loss, val_loss, train_acc, val_acc): Plots training and validation loss and accuracy over time.
        """
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.test_loader = test_loader
        self.criterion = criterion
        self.optimizer = optimizer
        self.device = device
        self.model.to(device)
        self.best_accuracy = 0.0

    def train(self, epochs, patience=3):
        train_losses = []
        train_accuracies = []
        val_losses = []
        val_accuracies = []
        best_val_acc = 0.0
        patience_counter = 0
        for epoch in range(epochs):
            # Training
            self.model.train()
            running_loss = 0.0
            correct_predictions = 0
            total_predictions = 0
            for inputs, labels in self.train_loader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                self.optimizer.zero_grad()
                outputs = self.model(inputs)
                _, preds = torch.max(outputs, 1)
                loss = self.criterion(outputs, labels)
                loss.backward()
                self.optimizer.step()
                running_loss += loss.item() * inputs.size(0)
                correct_predictions += torch.sum(preds == labels.data).detach().cpu().numpy()
                total_predictions += labels.size(0)
            epoch_loss = running_loss / len(self.train_loader.dataset)
            epoch_acc = correct_predictions / total_predictions
            train_losses.append(epoch_loss)
            train_accuracies.append(epoch_acc)
            
            # Validation
            self.model.eval()
            running_val_loss = 0.0
            correct_val_predictions = 0
            total_val_predictions = 0
            with torch.no_grad():
                for inputs, labels in self.val_loader:
                    inputs, labels = inputs.to(self.device), labels.to(self.device)
                    outputs = self.model(inputs)
                    _, preds = torch.max(outputs, 1)
                    loss = self.criterion(outputs, labels)
                    running_val_loss += loss.item() * inputs.size(0)
                    correct_val_predictions += torch.sum(preds == labels.data).detach().cpu().numpy()
                    total_val_predictions += labels.size(0)
            epoch_val_loss = running_val_loss / len(self.val_loader.dataset)
            epoch_val_acc = correct_val_predictions / total_val_predictions
            val_losses.append(epoch_val_loss)
            val_accuracies.append(epoch_val_acc)

            print(f'Epoch {epoch+1}/{epochs} || Train Loss: {epoch_loss:.4f} || Train Acc: {epoch_acc:.4F} || Val Loss: {epoch_val_loss:.4f} || Val Acc: {epoch_val_acc:.4f}')

            # Early stopping
            if epoch_val_acc > best_val_acc:
                best_val_acc = epoch_val_acc
                patience_counter = 0
            else:
                patience_counter += 1
                if patience_counter >= patience:
                    print("Early stopping")
                    break
         
        return train_losses, train_accuracies, val_losses, val_accuracies
    
    def evaluate(self):
        self.model.eval()
        correct_predictions = 0
        total_predictions = 0
        with torch.no_grad():
            for inputs, labels in self.test_loader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                outputs = self.model(inputs)
                _, preds = torch.max(outputs, 1)
                correct_predictions += torch.sum(preds == labels.data)
                total_predictions += labels.size(0)
        test_acc = correct_predictions / total_predictions
        print(f'Test Accuracy: {test_acc:.4f}')
        return test_acc
    
    def predict(self, inputs):
        self.model.eval()
        with torch.no_grad():
            inputs = inputs.to(self.device)
            outputs = self.model(inputs)
            _, preds = torch.max(outputs, 1)
        return preds
    
    @staticmethod
    def plot_metrics(train_loss, val_loss, train_acc, val_acc):
        epochs = range(1, len(train_loss) + 1)

        fig, axs = plt.subplots(2)

        # Subplot for loss
        axs[0].plot(epochs, train_loss, 'g', label='Training Loss')
        axs[0].plot(epochs, val_loss, 'b', label='Validation Loss')
        axs[0].set_title('Training and Validation Loss')
        axs[0].set_xlabel('Epochs')
        axs[0].set_ylabel('Loss')
        axs[0].legend()

        # Subplot for accuracy
        axs[1].plot(epochs, train_acc, 'g', label='Training Accuracy')
        axs[1].plot(epochs, val_acc, 'b', label='Validation Accuracy')
        axs[1].set_title('Training and Validation Accuracy')
        axs[1].set_xlabel('Epochs')
        axs[1].set_ylabel('Accuracy')
        axs[1].legend()

        plt.tight_layout()
        plt.show()
    